const {Student}= require('../models/user')


function addStudent(sname,id,subject,cgpa)
{
    
return Student.findOne({sname})
    .then(student=>{
      
        if(student)
        {
           
            return{
                
                statusCode:400,
                message:"Student already exists!"
            }
        }
        
        const newStudent=new Student({sname,id,subject,cgpa})
         newStudent.save()
        return{
            statusCode:200,
            message:"Successfully registered"
        }
     } )
}
    

function deleteStudent(id)
{
    
return Student.findOne({id})

    .then(student=>{
      
        if(!student)
        {
           
            return{
                
                statusCode:400,
                message:"Student doesnot exist!"
            }
        }
        
      Student.findOneAndRemove({id:id}).exec();
    //Student.save()
        return{
            statusCode:200,
            message:"Successfully deleted"
        }
     } )
}
    





module.exports={
    getStudents:()=>{
        
        return Student.find()
        .then(student=>{
            return student
        })
      
    },
    addStudent:addStudent,
    deleteStudent:deleteStudent
}