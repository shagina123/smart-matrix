var express = require('express');
var router = express.Router();
var Student=require('../services/Student')


/* GET Students list. */
router.get('/', function(req, res, next) {
  Student.getStudents()
  .then(data=>{res.send(data)})
  
  
});


router.post('/register',function(req,res,next){
  let sname=req.body.sname
        let id=req.body.id
        let cgpa=req.body.cgpa
        let subject=req.body.subject
       
        Student.addStudent(sname,id,subject,cgpa)
           .then(data=>{
               res.status(data.statusCode).send({message:data.message})
           })
});

router.post('/delete',function(req,res,next){
        let id=req.body.id
        
       
        Student.deleteStudent(id)
           .then(data=>{
               res.status(data.statusCode).send({message:data.message})
           })
});


module.exports = router;
