const mongoose=require('mongoose')
const Student=mongoose.model('Student',{

    sname:String,
    id:Number,
    subject:String,
    
    cgpa:Number,
})
module.exports={Student}